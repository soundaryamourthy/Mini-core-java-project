package com.project;

import java.util.Scanner;

public class BookStore1 extends BookStore{
	public static void main(String[] args) {
		String name,email,address,bookname;
		int i;
		double pin,no;
	System.out.println("*********WELCOME TO ONLINE BOOKSTORE*********");
	System.out.println("Register your details to buy a book");
	Scanner sc = new Scanner(System.in);
	name=sc.next();
	System.out.println("Enter your name:");
	name=sc.next();
	System.out.println("Enter your ph.no:");
	no=sc.nextDouble();
	System.out.println("Enter your email id:");
	email=sc.next();
	System.out.println("Enter your address:");
	address=sc.next();
	System.out.println("Registered Successfully!!!!!");
	BookStore bs = new BookStore();
	bs.msg();
	}

}
