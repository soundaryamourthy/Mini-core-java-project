package com.project;

import java.util.Scanner;

public class BookStore {
	 void msg() {
		 System.out.println("###@Choose the book@###");
		 System.out.println("1.mystery");
		 System.out.println("2.fantasy");
		 System.out.println("3.thriller");
		 System.out.println("4.childrens literature");
		 System.out.println("5.historical fiction");
		System.out.println("Enter the book name");
		Scanner sc = new Scanner(System.in);
		String input=sc.next();
	switch(input) {
	case "1.mystery":
		System.out.println("Mystery is in stock\n"+"price=250\n");
		System.out.println("enter how many book want:");
		Scanner my=new Scanner(System.in);
		int get4=my.nextInt();
		int tot1=250*get4;
		System.out.print("total book price is "+tot1);
	break;
	case "2.fantasy":
		System.out.println("Fantasy is in stock\n"+"price=500\n");
		System.out.println("enter how many book want:");
		Scanner fa=new Scanner(System.in);
		int get5=fa.nextInt();
		int tot2=500*get5;
		System.out.print("total book price is \n"+tot2);
	break;
	case "3.thriller":
		System.out.println("Thriller is in stock\n"+"price=250\n");
		System.out.println("enter how many book want:");
		Scanner th=new Scanner(System.in);
		int get6=th.nextInt();
		int tot3=250*get6;
		System.out.print("total book price is \n"+tot3);
	break;
	case "4.childrens literatute":
		System.out.println("childrens litrature is in stock\n"+"price=350\n");
		System.out.println("enter how many book want:");
		Scanner ch=new Scanner(System.in);
		int get7=ch.nextInt();
		int tot4=350*get7;
		System.out.print("total book price is "+tot4);
	break;
	case "5.historical fiction":
		System.out.println("Historical fiction is in stock\n"+"price=550\n");
		System.out.println("enter how many book want:");
		Scanner hi=new Scanner(System.in);
		int get8=hi.nextInt();
		int tot5=550*get8;
		System.out.print("total book price is \n"+tot5);
	break;
	default:
		System.out.println("---This book is not found---");
		System.exit(0);
	}
Scanner pu = new Scanner(System.in);
System.out.println("\nSelect the payment method");
System.out.println("1.press ONE for cash on delivery");
System.out.println("2.press TWO for online payment");
int num=pu.nextInt();
      if(num==1) {
    	  System.out.println("you pressed cash on delivery" +" "+ "your order is confirmed");
    	  System.out.println("Soon we have deliver the book");
    	  System.out.println("Thank you for choosing us!!!!!!");
    	  System.exit(0);
      }
      else {
    	  System.out.println("you pressed online payment"+ " " +"please fill your details");
    	  System.out.println("Enter your bank name:");
    	  Scanner cc = new Scanner(System.in);
    	  String get=cc.next();
    	  System.out.println("Enter your bank ACCOUNT NO:");
    	  Scanner pp = new Scanner(System.in);
    	  double get1=pp.nextDouble();
    	  System.out.println("Enter your bank IFSC code:");
    	  Scanner ss = new Scanner(System.in);
    	  double get2=ss.nextDouble();
    	  System.out.println("Soon we have deliver the book.....");
    	  System.out.println("Thank you for choosing us!!!!!!");
      }
	}
}